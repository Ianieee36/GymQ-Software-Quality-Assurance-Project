# Screenshot index

Images are unchanged copies. Current manual checks and older automated/regression images are listed separately; generated headless screenshots do not count as human usability evidence.

Total screenshots: **184**.

## Manual checks — 16–17 October 2026

| File | Case or evidence group |
|---|---|
| [MAN-001-Final-FIFO.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Final-FIFO.png) | MAN-001 |
| [MAN-001-First-Left.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-First-Left.png) | MAN-001 |
| [MAN-001-Initial-Already-Queued.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Initial-Already-Queued.png) | MAN-001 |
| [MAN-001-Owner-Session.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Owner-Session.png) | MAN-001 |
| [MAN-001-Second-Left.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Second-Left.png) | MAN-001 |
| [MAN-001-Trial1-Before-Click.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial1-Before-Click.png) | MAN-001 |
| [MAN-001-Trial1-Click-Marker.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial1-Click-Marker.png) | MAN-001 |
| [MAN-001-Trial1-Position.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial1-Position.png) | MAN-001 |
| [MAN-001-Trial2-Before-Click.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial2-Before-Click.png) | MAN-001 |
| [MAN-001-Trial2-Click-Marker.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial2-Click-Marker.png) | MAN-001 |
| [MAN-001-Trial2-Position.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial2-Position.png) | MAN-001 |
| [MAN-001-Trial3-After-Leave.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-After-Leave.png) | MAN-001 |
| [MAN-001-Trial3-Before-Click.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Before-Click.png) | MAN-001 |
| [MAN-001-Trial3-Click-Marker.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Click-Marker.png) | MAN-001 |
| [MAN-001-Trial3-Detail-Route.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Detail-Route.png) | MAN-001 |
| [MAN-001-Trial3-Final-FIFO.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Final-FIFO.png) | MAN-001 |
| [MAN-001-Trial3-Initial.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Initial.png) | MAN-001 |
| [MAN-001-Trial3-Position.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-001-Trial3-Position.png) | MAN-001 |
| [MAN-003-EndMySession-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Before.png) | MAN-003 |
| [MAN-003-EndMySession-Claimed.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Claimed.png) | MAN-003 |
| [MAN-003-EndMySession-Handover.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Handover.png) | MAN-003 |
| [MAN-003-EndMySession-Nudge.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Nudge.png) | MAN-003 |
| [MAN-003-EndMySession-Response-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Response-Control.png) | MAN-003 |
| [MAN-003-EndMySession-Setup.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-EndMySession-Setup.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Before.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Handover.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Handover.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Last-Pending.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Last-Pending.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Midpoint.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Midpoint.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Nudge.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Nudge.png) | MAN-003 |
| [MAN-003-Realtime-Timeout-Setup.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-Realtime-Timeout-Setup.png) | MAN-003 |
| [MAN-003-StillUsing-After.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-StillUsing-After.png) | MAN-003 |
| [MAN-003-StillUsing-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-003-StillUsing-Before.png) | MAN-003 |
| [MAN-004-Setup-FirstWaiter.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Setup-FirstWaiter.png) | MAN-004 |
| [MAN-004-Setup-Ready.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Setup-Ready.png) | MAN-004 |
| [MAN-004-Setup-TwoWaiters.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Setup-TwoWaiters.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Account-Switch-Complete.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Account-Switch-Complete.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Before.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Claimed.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Claimed.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-First-Offer.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-First-Offer.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Handover.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Handover.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Last-Pending.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Last-Pending.png) | MAN-004 |
| [MAN-004-Unclaimed-Timeout-Midpoint.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-004-Unclaimed-Timeout-Midpoint.png) | MAN-004 |
| [MAN-005-Blank-Description-Validation.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Blank-Description-Validation.png) | MAN-005 |
| [MAN-005-Report-Initial-Selection.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Report-Initial-Selection.png) | MAN-005 |
| [MAN-005-Report-Selector-Open-SquatRack.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Report-Selector-Open-SquatRack.png) | MAN-005 |
| [MAN-005-Report-Submitted.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Report-Submitted.png) | MAN-005 |
| [MAN-005-Report-Treadmill-Before-Submit.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Report-Treadmill-Before-Submit.png) | MAN-005 |
| [MAN-005-Setup-Details.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Setup-Details.png) | MAN-005 |
| [MAN-005-SquatRack-Details-Observation.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-SquatRack-Details-Observation.png) | MAN-005 |
| [MAN-005-Staff-After-Blank-Rejection.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Staff-After-Blank-Rejection.png) | MAN-005 |
| [MAN-005-Staff-Report-Verified.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-005-Staff-Report-Verified.png) | MAN-005 |
| [MAN-006-Confirm-R3-After.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Confirm-R3-After.png) | MAN-006 |
| [MAN-006-Confirm-R3-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Confirm-R3-Before.png) | MAN-006 |
| [MAN-006-Confirm-R3-Confirm-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Confirm-R3-Confirm-Control.png) | MAN-006 |
| [MAN-006-Confirm-R3-Retained-State.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Confirm-R3-Retained-State.png) | MAN-006 |
| [MAN-006-Reject-R2-After.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Reject-R2-After.png) | MAN-006 |
| [MAN-006-Reject-R2-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Reject-R2-Before.png) | MAN-006 |
| [MAN-006-Reject-R2-Reject-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Reject-R2-Reject-Control.png) | MAN-006 |
| [MAN-006-Reject-R2-Retained-State.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Reject-R2-Retained-State.png) | MAN-006 |
| [MAN-006-Two-Pending-Reports-Baseline.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-006-Two-Pending-Reports-Baseline.png) | MAN-006 |
| [MAN-007-Confirm-R4-Actual-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Confirm-R4-Actual-Before.png) | MAN-007 |
| [MAN-007-Confirm-R4-After-Confirm.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Confirm-R4-After-Confirm.png) | MAN-007 |
| [MAN-007-Confirm-R4-Confirm-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Confirm-R4-Confirm-Control.png) | MAN-007 |
| [MAN-007-Confirm-R4-Owner-Equipment-Access.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Confirm-R4-Owner-Equipment-Access.png) | MAN-007 |
| [MAN-007-Confirm-R4-Owner-Session-Reopened.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Confirm-R4-Owner-Session-Reopened.png) | MAN-007 |
| [MAN-007-Ready-Before-Confirm-R4.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Ready-Before-Confirm-R4.png) | MAN-007 |
| [MAN-007-Retry-After-Owner-Finish.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-After-Owner-Finish.png) | MAN-007 |
| [MAN-007-Retry-Bike-After.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Bike-After.png) | MAN-007 |
| [MAN-007-Retry-Bike-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Bike-Before.png) | MAN-007 |
| [MAN-007-Retry-Bike-Continuing.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Bike-Continuing.png) | MAN-007 |
| [MAN-007-Retry-Christian-Cancellation.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-Cancellation.png) | MAN-007 |
| [MAN-007-Retry-Christian-Cleared.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-Cleared.png) | MAN-007 |
| [MAN-007-Retry-Christian-First.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-First.png) | MAN-007 |
| [MAN-007-Retry-Christian-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-Login.png) | MAN-007 |
| [MAN-007-Retry-Christian-Notice-Detail.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-Notice-Detail.png) | MAN-007 |
| [MAN-007-Retry-Christian-Revisit.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Christian-Revisit.png) | MAN-007 |
| [MAN-007-Retry-Final-State.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Final-State.png) | MAN-007 |
| [MAN-007-Retry-Fresh-Owner.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Fresh-Owner.png) | MAN-007 |
| [MAN-007-Retry-Lorenz-Cancellation.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Lorenz-Cancellation.png) | MAN-007 |
| [MAN-007-Retry-Lorenz-Dismiss-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Lorenz-Dismiss-Control.png) | MAN-007 |
| [MAN-007-Retry-Lorenz-Queue-Empty.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Lorenz-Queue-Empty.png) | MAN-007 |
| [MAN-007-Retry-Lorenz-Revisit.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Lorenz-Revisit.png) | MAN-007 |
| [MAN-007-Retry-Owner-Finish-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Owner-Finish-Control.png) | MAN-007 |
| [MAN-007-Retry-Owner-View-After-Fault.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Owner-View-After-Fault.png) | MAN-007 |
| [MAN-007-Retry-Report-Input.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Report-Input.png) | MAN-007 |
| [MAN-007-Retry-Report-Submitted.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Report-Submitted.png) | MAN-007 |
| [MAN-007-Retry-Two-Waiters-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Retry-Two-Waiters-Before.png) | MAN-007 |
| [MAN-007-Setup-Christian-First-In-E2-Queue.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Setup-Christian-First-In-E2-Queue.png) | MAN-007 |
| [MAN-007-Setup-Fresh-Lorenz-E2.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Setup-Fresh-Lorenz-E2.png) | MAN-007 |
| [MAN-007-Setup-Two-Active-Sessions.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Setup-Two-Active-Sessions.png) | MAN-007 |
| [MAN-007-Setup-Two-Waiters.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-007-Setup-Two-Waiters.png) | MAN-007 |
| [MAN-008-Before-Handover.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Before-Handover.png) | MAN-008 |
| [MAN-008-Bike-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Bike-Before.png) | MAN-008 |
| [MAN-008-Bike-Finish-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Bike-Finish-Control.png) | MAN-008 |
| [MAN-008-Christian-First.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Christian-First.png) | MAN-008 |
| [MAN-008-Claim-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Claim-Control.png) | MAN-008 |
| [MAN-008-Claimed-Rack.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Claimed-Rack.png) | MAN-008 |
| [MAN-008-Current-Bike.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Current-Bike.png) | MAN-008 |
| [MAN-008-Final-Equipment.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Final-Equipment.png) | MAN-008 |
| [MAN-008-Lorenz-Next.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Lorenz-Next.png) | MAN-008 |
| [MAN-008-Lorenz-Second.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Lorenz-Second.png) | MAN-008 |
| [MAN-008-Original-Offer.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Original-Offer.png) | MAN-008 |
| [MAN-008-Recovery-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Recovery-Control.png) | MAN-008 |
| [MAN-008-Resumed-Offer.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-008-Resumed-Offer.png) | MAN-008 |
| [MAN-009-Available-After-End.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-009-Available-After-End.png) | MAN-009 |
| [MAN-009-Available-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-009-Available-Before.png) | MAN-009 |
| [MAN-009-First-Start.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-009-First-Start.png) | MAN-009 |
| [MAN-009-Fresh-Session-Final.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-009-Fresh-Session-Final.png) | MAN-009 |
| [MAN-009-Second-Start.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-009-Second-Start.png) | MAN-009 |
| [MAN-014-Caption-Equipment-Nav-Name-Defect.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Equipment-Nav-Name-Defect.png) | MAN-014 |
| [MAN-014-Caption-Final-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Final-Login.png) | MAN-014 |
| [MAN-014-Caption-Header-Profile.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Header-Profile.png) | MAN-014 |
| [MAN-014-Caption-Image-Name-Defect.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Image-Name-Defect.png) | MAN-014 |
| [MAN-014-Caption-Initial-Login-Rejected.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Initial-Login-Rejected.png) | MAN-014 |
| [MAN-014-Caption-Logged-In.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Logged-In.png) | MAN-014 |
| [MAN-014-Caption-Login-Second-Attempt.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Login-Second-Attempt.png) | MAN-014 |
| [MAN-014-Caption-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Login.png) | MAN-014 |
| [MAN-014-Caption-Logout.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Logout.png) | MAN-014 |
| [MAN-014-Caption-Password.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Password.png) | MAN-014 |
| [MAN-014-Caption-Profile-Nav-Name-Defect.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Profile-Nav-Name-Defect.png) | MAN-014 |
| [MAN-014-Caption-Profile-Opened.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Profile-Opened.png) | MAN-014 |
| [MAN-014-Caption-Returned-To-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Returned-To-Login.png) | MAN-014 |
| [MAN-014-Caption-Start-Session.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Start-Session.png) | MAN-014 |
| [MAN-014-Caption-Text-Field-Hint.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Text-Field-Hint.png) | MAN-014 |
| [MAN-014-Caption-Username-Revisited.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Username-Revisited.png) | MAN-014 |
| [MAN-014-Caption-Username.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Caption-Username.png) | MAN-014 |
| [MAN-014-Logged-In.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Logged-In.png) | MAN-014 |
| [MAN-014-Login-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Login-Before.png) | MAN-014 |
| [MAN-014-Login-Button-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Login-Button-Focus.png) | MAN-014 |
| [MAN-014-Logout-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Logout-Focus.png) | MAN-014 |
| [MAN-014-Password-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Password-Focus.png) | MAN-014 |
| [MAN-014-Password-Revisited.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Password-Revisited.png) | MAN-014 |
| [MAN-014-Profile-Nav-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Profile-Nav-Focus.png) | MAN-014 |
| [MAN-014-Profile-Opened.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Profile-Opened.png) | MAN-014 |
| [MAN-014-Returned-To-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Returned-To-Login.png) | MAN-014 |
| [MAN-014-Username-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Username-Focus.png) | MAN-014 |
| [MAN-014-Username-Revisited.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-Username-Revisited.png) | MAN-014 |
| [MAN-014-VoiceOver-Equipment-View.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Equipment-View.png) | MAN-014 |
| [MAN-014-VoiceOver-Logged-In.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Logged-In.png) | MAN-014 |
| [MAN-014-VoiceOver-Login-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Login-Before.png) | MAN-014 |
| [MAN-014-VoiceOver-Password-Entered.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Password-Entered.png) | MAN-014 |
| [MAN-014-VoiceOver-Password-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Password-Focus.png) | MAN-014 |
| [MAN-014-VoiceOver-Profile-Nav-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Profile-Nav-Focus.png) | MAN-014 |
| [MAN-014-VoiceOver-Profile-Opened.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Profile-Opened.png) | MAN-014 |
| [MAN-014-VoiceOver-Returned-To-Login.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Returned-To-Login.png) | MAN-014 |
| [MAN-014-VoiceOver-Username-Entered.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Username-Entered.png) | MAN-014 |
| [MAN-014-VoiceOver-Username-Focus.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-014-VoiceOver-Username-Focus.png) | MAN-014 |
| [01-Lorenz-Report-Submitted.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-015-Isolated-Restart/run-evidence/01-Lorenz-Report-Submitted.png) | MAN-015 |
| [02-Staff-Pending-R2-Before-Quit.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-015-Isolated-Restart/run-evidence/02-Staff-Pending-R2-Before-Quit.png) | MAN-015 |
| [03-Staff-Pending-R2-After-Relaunch.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/MAN-015-Isolated-Restart/run-evidence/03-Staff-Pending-R2-After-Relaunch.png) | MAN-015 |
| [SUP-Restore-Active-E2-After.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/SUP-Restore-Active-E2-After.png) | SUP-Restore-Active-E2 |
| [SUP-Restore-Active-E2-Before.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/SUP-Restore-Active-E2-Before.png) | SUP-Restore-Active-E2 |
| [SUP-Restore-Active-E2-Restore-Control.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/SUP-Restore-Active-E2-Restore-Control.png) | SUP-Restore-Active-E2 |
| [SUP-Restore-Active-E2-Retained-State.png](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/SUP-Restore-Active-E2-Retained-State.png) | SUP-Restore-Active-E2 |

## Historical defect and regression evidence — 11 October 2026

| File | Case or evidence group |
|---|---|
| [claim-active-session-lock.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/defects/historical/2026-10-08-a3b090f/claim-active-session-lock.png) | Historical regression |
| [01-equipment.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/01-equipment.png) | Historical regression |
| [02-queue.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/02-queue.png) | Historical regression |
| [03-nudge.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/03-nudge.png) | Historical regression |
| [04-your-turn.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/04-your-turn.png) | Historical regression |
| [05-session.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/05-session.png) | Historical regression |
| [06-report.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/06-report.png) | Historical regression |
| [07-report-submitted.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/07-report-submitted.png) | Historical regression |
| [08-staff.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/08-staff.png) | Historical regression |
| [09-profile.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/09-profile.png) | Historical regression |
| [12-small-window.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/12-small-window.png) | Historical regression |
| [13-demo-controls.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/13-demo-controls.png) | Historical regression |
| [gq-cancel-banner-over-nudge.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq-cancel-banner-over-nudge.png) | Historical regression |
| [gq01-claim-recovery.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq01-claim-recovery.png) | gq01 |
| [gq02-queue-cancelled.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq02-queue-cancelled.png) | gq02 |
| [gq05-nonowner-detail-out-of-service.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-nonowner-detail-out-of-service.png) | gq05 |
| [gq05-nonowner-equipment-out-of-service.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-nonowner-equipment-out-of-service.png) | gq05 |
| [gq05-owner-detail-out-of-service.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-owner-detail-out-of-service.png) | gq05 |
| [gq05-owner-detail-session-reachable.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-owner-detail-session-reachable.png) | gq05 |
| [gq05-owner-equipment-out-of-service.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-owner-equipment-out-of-service.png) | gq05 |
| [gq05-owner-equipment-session-reachable.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq05-owner-equipment-session-reachable.png) | gq05 |
| [gq07-session-title-MaxDurationReached.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq07-session-title-MaxDurationReached.png) | gq07 |
| [gq07-session-title-NudgeResponse.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq07-session-title-NudgeResponse.png) | gq07 |
| [gq07-session-title-NudgeTimeout.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq07-session-title-NudgeTimeout.png) | gq07 |
| [gq08-answered-nudge-feedback-cleared.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq08-answered-nudge-feedback-cleared.png) | gq08 |
| [gq08-pending-nudge-feedback.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq08-pending-nudge-feedback.png) | gq08 |
| [gq09-member-avatar-profile.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq09-member-avatar-profile.png) | gq09 |
| [gq09-staff-avatar-policy.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/gq09-staff-avatar-policy.png) | gq09 |
| [report-success-nudge-finish.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/report-success-nudge-finish.png) | Historical regression |
| [report-success-nudge-still-using.png](Testing/GymQ-Final-QA-Evidence-2026-10-11/screenshots/report-success-nudge-still-using.png) | Historical regression |
