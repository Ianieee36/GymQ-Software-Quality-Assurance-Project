# GymQ supporting tests and evidence

Lorenz Soriano (18011129) · Submission copy prepared 18 October 2026

This folder contains the supporting test records, screenshots and observation notes for the final report. The report is maintained separately in the team's OneDrive document and is not duplicated here. Application source and Git history remain in the team repository.

| Report evidence | Included record |
|---|---|
| Latest automated run | [253-test result](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/TestResults/fb949cf.trx), [test log](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/Automated_Test_fb949cf.log) and [build evidence overview](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/README.md) |
| Manual checks | [Manual_Check_Progress.csv](Testing/GymQ-New-Commit-Review-2026-10-16-fb949cf/manual-evidence/Manual_Check_Progress.csv), case summaries and observations in the same manual-evidence folder |
| Screenshot evidence | [Screenshot_Index.md](Screenshot_Index.md) |
| Defects and root causes | [defect-register.csv](Testing/GymQ-Final-QA-Evidence-2026-10-11/defects/defect-register.csv) and [rca-evidence.json](Testing/GymQ-Final-QA-Evidence-2026-10-11/defects/rca-evidence.json) |
| Quality testing and test definitions | [quality-area-evidence.csv](Testing/GymQ-Final-QA-Evidence-2026-10-11/metrics/quality-area-evidence.csv) and [test-case-definitions.json](Testing/GymQ-Final-QA-Evidence-2026-10-11/execution/test-case-definitions.json) |
| Historical coverage measurement | [coverage.cobertura.xml](Testing/GymQ-Final-QA-Evidence-2026-10-11/metrics/coverage.cobertura.xml) |
| Scope and handling notes | [Evidence_Notes.md](Evidence_Notes.md) |
| File integrity | [SHA256_Manifest.json](SHA256_Manifest.json) |

The current automated result is **253/253 at fb949cf on 16 October 2026**. The 11 October package records **248/248 at 849d8b6** and the regression checks carried out for that revision. These are separate runs. The older coverage file combines Core and Desktop; it does not establish the report's Core-only 70% criterion.

Manual evidence covers parts of 11 of the 16 original cases, not 11 complete case passes. Open findings and unrun checks remain recorded. Packaging these files does not add test execution or release approval.

Submission copies omit local paths and reviewer/tool metadata; recorded results and build details are retained. The manifest identifies the submitted files and notes which text records were made portable.
