using System.Text;
using GymQ.Persistence;
using GymQ.Services;

var lines = new StringBuilder();
void Log(string text) { Console.WriteLine(text); lines.AppendLine(text); }
var evidenceDirectory = args.Length > 0 ? Path.GetFullPath(args[0]) : Directory.GetCurrentDirectory();
var temporaryDirectory = Path.Combine(Path.GetTempPath(), "gymq-current-core-probe-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(temporaryDirectory);
var statePath = Path.Combine(temporaryDirectory, "state.json");
var success = false;
try
{
    Log("GymQ latest-main Core diagnostic (9dcf564)");
    Log("References the existing Release Core DLL; no product project reference or real app store.");
    Log("Fixed clock: 2026-10-10T00:00:00Z; no clock advance during either case.");
    Log("");
    Log("CASE 1: answered nudge cooldown across persistent restart");
    var clock = new FixedClock();
    string sessionId;
    using (var store = new JsonGymStateStore(statePath))
    {
        var gym = GymSession.OpenPersistent(store, seedWhenMissing: false, clock: clock);
        gym.Start("E1", gym.FindMember("M001"));
        gym.Join("E1", gym.FindMember("M002"));
        gym.SendNudge("E1", gym.FindMember("M002"));
        gym.Respond("E1", gym.FindMember("M001"), stillUsing: true);
        sessionId = gym.Sessions.ReadActiveSession("E1")!.SessionId;
        var snapshot = gym.CaptureState();
        var remaining = gym.Nudging.CooldownRemaining(sessionId, "M002");
        var saved = store.Load()!;
        Log($"Before restart: open nudges={snapshot.Nudges.Length}; cooldowns={snapshot.NudgeCooldowns.Length}; remaining={remaining.TotalSeconds:0} seconds.");
        Log($"Actual JSON before restart: open nudges={saved.Nudges.Length}; cooldowns={saved.NudgeCooldowns.Length}.");
        if (snapshot.Nudges.Length != 0 || snapshot.NudgeCooldowns.Length != 1 || remaining != TimeSpan.FromMinutes(5) || saved.NudgeCooldowns.Length != 1)
            throw new InvalidOperationException("The expected persisted precondition was not reached.");
    }
    using (var store = new JsonGymStateStore(statePath))
    {
        var restored = GymSession.OpenPersistent(store, seedWhenMissing: false, clock: clock);
        var remaining = restored.Nudging.CooldownRemaining(sessionId, "M002");
        var snapshot = restored.CaptureState();
        var saved = store.Load()!;
        var sameSession = restored.Sessions.ReadActiveSession("E1")!.SessionId == sessionId;
        Log($"After restart: same active session={sameSession}; open nudges={snapshot.Nudges.Length}; cooldowns={snapshot.NudgeCooldowns.Length}; remaining={remaining.TotalSeconds:0} seconds.");
        Log($"Actual JSON after startup save: cooldowns={saved.NudgeCooldowns.Length}.");
        var accepted = true;
        try { restored.SendNudge("E1", restored.FindMember("M002")); }
        catch (InvalidOperationException ex) { accepted = false; Log("Immediate request rejected: " + ex.Message); }
        Log($"Immediate request by the same member, same session: accepted={accepted}.");
        if (!sameSession || remaining != TimeSpan.Zero || snapshot.NudgeCooldowns.Length != 0 || saved.NudgeCooldowns.Length != 0 || !accepted)
            throw new InvalidOperationException("The suspected restart regression did not reproduce.");
        Log("RESULT: reproduced; restart removes an unexpired saved cooldown after Still Using.");
    }

    Log("");
    Log("CASE 2: replacement front member under the current cooldown policy");
    var policyGym = new GymSession(seed: false, clock: new FixedClock());
    policyGym.Start("E1", policyGym.FindMember("M001"));
    var activeId = policyGym.Sessions.ReadActiveSession("E1")!.SessionId;
    policyGym.Join("E1", policyGym.FindMember("M002"));
    policyGym.Join("E1", policyGym.FindMember("M003"));
    policyGym.SendNudge("E1", policyGym.FindMember("M002"));
    policyGym.Respond("E1", policyGym.FindMember("M001"), stillUsing: true);
    policyGym.Leave("E1", policyGym.FindMember("M002"));
    var previousRemaining = policyGym.Nudging.CooldownRemaining(activeId, "M002");
    policyGym.SendNudge("E1", policyGym.FindMember("M003"));
    var sameActive = policyGym.Sessions.ReadActiveSession("E1")!.SessionId == activeId;
    Log($"Previous nudger M002 still has {previousRemaining.TotalSeconds:0} seconds cooldown; elapsed since first request=0 seconds.");
    Log($"Replacement M003 immediate request: accepted=True; same active session={sameActive}; open requester={policyGym.Nudges.Single().RequestedBy}.");
    if (previousRemaining != TimeSpan.FromMinutes(5) || !sameActive || policyGym.Nudges.Single().RequestedBy != "M003")
        throw new InvalidOperationException("The current replacement-front policy did not reproduce.");
    Log("RESULT: per-session/per-requester policy confirmed; the documented shared-equipment rule is not enforced.");
    success = true;
}
catch (Exception ex)
{
    Log("DIAGNOSTIC FAILURE: " + ex);
}
finally
{
    Directory.Delete(temporaryDirectory, recursive: true);
    Log("");
    Log("Temporary store removed; product repository and real application data unchanged.");
    File.WriteAllText(Path.Combine(evidenceDirectory, "core-regression-results.txt"), lines.ToString());
}
return success ? 0 : 1;

sealed class FixedClock : TimeProvider
{
    public override DateTimeOffset GetUtcNow() => new(2026, 10, 10, 0, 0, 0, TimeSpan.Zero);
}
