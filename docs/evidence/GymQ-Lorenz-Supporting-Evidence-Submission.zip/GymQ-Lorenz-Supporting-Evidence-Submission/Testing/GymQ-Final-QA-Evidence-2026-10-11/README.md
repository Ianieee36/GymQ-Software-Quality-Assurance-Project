# Historical defect and quality evidence — 11 October 2026

These records describe revision `849d8b6f5f1838aaf52e131d8caa5f7a4d504c2c`, not the later fb949cf run. The main result is [submission-candidate.trx](TestResults/submission-candidate.trx): 248 passed, 0 failed, 0 not executed. [verification-summary.json](verification/verification-summary.json) retains the build and test provenance.

[defect-register.csv](defects/defect-register.csv) and [rca-evidence.json](defects/rca-evidence.json) connect the reported defects to causes, fixes and named regression results. Historical reproduction records and screenshots are included where needed to understand those records. The existing defect IDs and original requirement mapping are preserved; the final report's updated RTM uses its stated final requirement numbering.

[quality-area-evidence.csv](metrics/quality-area-evidence.csv) maps quality scenarios to the selected [test definitions](execution/test-case-definitions.json) and [execution records](execution/test-execution-results.json).

[coverage.cobertura.xml](metrics/coverage.cobertura.xml) is the original combined Core and Desktop measurement. It does not establish a Core-only coverage threshold, accessibility acceptance, native Windows execution or six-month retention.

The current automated results are in the separate fb949cf evidence folder. No historical result has been relabelled as a newer run.
