# Build and manual-check evidence

The automated run on 16 October 2026 tested commit `fb949cf7888976f1b51a39195b5a8dd84486c9ae`: **253 passed, 0 failed, 0 not executed**. Its results are in [fb949cf.trx](TestResults/fb949cf.trx) and [Automated_Test_fb949cf.log](Automated_Test_fb949cf.log). No tests were rerun while preparing this submission.

The manual checks were performed by Lorenz Soriano on 16–17 October. Christian, Jayden and Staff are prototype account names used in these checks. The two displayed device windows share one process; they do not establish separate physical-device synchronisation.

Use [Manual_Check_Progress.csv](manual-evidence/Manual_Check_Progress.csv) for the current case status. The original inventory is retained as a historical test definition, with its original NotRun statuses; it is not the final result list. The case summaries and observations explain which steps were observed and which remain unverified.

- MAN-001–009 have scoped workflow evidence. MAN-001 has local timing samples, not a normal-load performance result. MAN-008 remains partial because the member's ended-session history was not demonstrated.
- MAN-014 remains partial. Keyboard navigation was observed, but the caption-panel check found unclear accessible names. Those findings remain open. Scaling was not run.
- MAN-015 passed one source-build report persistence and normal-restart sub-check. The full package, installer and Windows criteria remain unverified.
- MAN-010, MAN-011, MAN-012, MAN-013 and MAN-016 were not run.

Screenshots and their case IDs are listed in the root Screenshot_Index.md. Some images are frames extracted from recordings reviewed during the original checks. Recordings and audio are excluded from this submission; screenshots alone cannot independently establish the full elapsed-time sequence or spoken output. The saved timing observations and VoiceOver caption screenshots retain the limits of that evidence.

The supplemental return-to-service observation shows an active equipment owner retaining access after restoration. It does not verify the exact session ID, unchanged deadline or cancellation non-revival.
