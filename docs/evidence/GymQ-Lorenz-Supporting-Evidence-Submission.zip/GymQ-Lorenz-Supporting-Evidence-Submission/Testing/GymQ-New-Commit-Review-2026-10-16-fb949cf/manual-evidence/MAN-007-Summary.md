# MAN-007: current result

**Passed for one retry I ran in the real app with local windows.**

The continuous retry shows:

- Christian first and Lorenz second in E2's queue, with Jayden owning E2.
- Staff confirms R-6, E2 becomes Out of Service and the queue empties.
- Both affected accounts get a cancellation message.
- Messages that were dismissed don't come back while I move around afterwards.
- Christian's separate bike session keeps going, with the time still counting up.

See [the full retry write-up](MAN-007-Retry-Observation.md) and [structured evidence](MAN-007-Retry-Observation.json). There was no active claim offer, so this doesn't check by hand that an already-open claim pop-up or its timer gets cancelled. Which exact app binary was running, real syncing between physical devices and release acceptance aren't covered.

The earlier [R-4 attempt](MAN-007-Confirm-R4-Observation.md) lost its prepared setup, so it doesn't count for the cancellation check. It hasn't been relabelled as a pass. The [restoration clip](SUP-Restore-Active-E2-Observation.md) only checks the equipment and member-card state.

**Where I left things:** On Device A, Jayden has finished E2, and E2 is still Out of Service. Device B is Gym Staff with 0 pending reports. E4 is still In Use by Christian, and his timer was last seen at 00:56. Check the actual state again before a later timed case, because the timers keep running.
