# MAN-006: rejecting R-2 in the real app

**Result for what I tested: Passed for one rejection trial.** My 10.245-second recording shows staff pressing Reject on R-2, the belt-noise test report I meant to reject. R-3 stays pending, and Treadmill #3 stays available in both local windows.

| Time in original video | What I saw |
|---|---|
| 0.000 s | Staff sees two pending reports, R-3 above R-2. Both are for Treadmill #3, which is Available in both windows. |
| 1.633 s | The pointer is on the highlighted Reject button on the lower R-2 card. |
| 2.772 s | R-2 is gone and the pending count is 1. R-3 and its safety-stop test description are still there. |
| 6.983 s | Still the same. The treadmill stays Available, and Lorenz's Squat Rack session still shows as active. |

The change in the list and the count is the visible feedback. I'm not claiming there's a separate rejection pop-up or a visible "Rejected" label, and I'm not working out an exact response time from these sampled frames.

## Evidence and what's still to check

- `MAN-006-Reject-R2.mov` (recording not included), SHA-256 `473059fc82abc38a52b22d212906029ee002d40e3966b80c1131a574e44c4862`.
- [Observation, frame timestamps and preservation hashes](MAN-006-Reject-R2-Observation.json). The four PNGs are frames taken straight from the video.
- Starting state: `MAN-006-Two-Pending-Reports-Baseline.json`. R-2 is the MAN-005-1610 belt-noise report and R-3 is the MAN-006-CONFIRM-1610 safety-stop report.
- Device A is Gym Staff and Device B is Lorenz. These are local windows sharing one process. This trial doesn't show delivery to a separate physical device or production-level authorisation security.
- Source checked: `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The recording doesn't prove the running app binary or package hash, whether a separate save file was used, or the host OS version.
- **At this point MAN-006 was only partly done.** Confirming R-3 and checking what the member then sees were still to come. A staff action on its own doesn't test blocking an unauthorised member from reviewing a report.

The original inventory, project source, report and presentation are unchanged. See [Manual_Check_Progress.csv](Manual_Check_Progress.csv).
