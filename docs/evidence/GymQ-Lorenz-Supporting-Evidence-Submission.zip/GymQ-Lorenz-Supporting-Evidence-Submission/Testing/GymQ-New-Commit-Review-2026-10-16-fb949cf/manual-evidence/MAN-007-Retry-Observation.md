# MAN-007: queue cancellation, continuous retry

**Result: Passed for one workflow I ran in the real app with local windows.** The 97.440-second recording shows two people waiting at the time, a separate active bike session, the fault being confirmed, both cancellation messages, an empty queue, and the bike keeping the same owner and timer. This retry gives the evidence that the earlier R-4 attempt was missing.

| Video time | What I saw |
|---|---|
| 0.000 s | Jayden owns Squat Rack #2 at 00:20; E4 is Available; no pending reports. |
| 3.997–9.997 s | Jayden reports E2 with the MAN-007-RETRY description. The confirmation appears and staff sees R-6. |
| 19.997 s | Christian starts the Recumbent Bike at 00:00 / 30:00. Staff shows it In Use. |
| 23.730 s | Christian is first in the queue for E2 and still has his bike session. |
| 49.783 s | Lorenz #2 behind Christian #1; Jayden still owns E2 at 01:10; bike In Use; R-6 ready to confirm. |
| 50.992 s | Lorenz sees the Queue cancelled banner, "You're no longer queued" and an empty queue list. Staff shows E2 Out of Service with 0 pending; the bike is still In Use. |
| 57.517–58.892 s | Pointer on the × of Lorenz's banner, then the banner is gone. It doesn't come back while he moves around during the time he's signed in. |
| 67.942–70.950 s | Quick login as Chris, then the E2 cancellation banner, then Christian's header is visible once it clears. |
| 72.833–76.992 s | Christian's bike session is still running, timer 00:53 then 00:56; time left 29:07 then 29:04. |
| 90.992–92.992 s | Jayden opens his E2 session while it's unavailable, then uses End Session. E2 stays Out of Service; the bike stays In Use. |

**Fault report:** R-6 · Jayden Marsh · Squat Rack #2. Description: `MAN-007-RETRY: Test only — rack safety pin needs inspection.` I read the ID from the recording and I'm not assuming anything about other reports in between.

Both messages say: "The queue for Squat Rack #2 has been cancelled because the equipment has been marked Out of Service." The banner covers the member's header. You can tell whose account it is from the frames on either side in the continuous sequence, including the quick login as Chris and his name showing after the banner clears. The exact moment Christian closes it isn't in the frames I picked, but the message arriving, clearing and not coming back while he moves around are all visible.

## Scope and where it came from

- `MAN-007-Retry-Continuous.mov` (recording not included), SHA-256 `f45698de5392d39ee859491bcf026ad7e20ba8a9352bafb5bbe1d843f567365c`.
- [Observation with 21 frame hashes and timestamps](MAN-007-Retry-Observation.json). The PNGs are frames taken straight from the video, with nothing on screen changed.
- Device A goes through Jayden, Christian, Lorenz, Christian and Jayden; **Device B stays as Gym Staff the whole time**. That's different from the window-switching order I'd planned, but it tests the same roles and states. The checks happen one after another in two local windows sharing one process. It isn't three members at once or separate physical devices.
- The bike session looks continuous because it's the same owner, the timer keeps going up and I didn't see it end or restart. The app doesn't show the backend session ID.
- There was no active claim offer before the fault, so this trial doesn't show a pending claim pop-up or its timer being cancelled. No new claim pop-up or repeated cancellation banner shows up after the confirmation in what I watched, but that doesn't guarantee what happens later.
- Source checked: `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The exact running binary hash, which source build it matches, whether the data was kept separate, and the OS version aren't confirmed. Automated results are credited to the build they were run on.
- Seeing the current owner's view and finishing the session after maintenance give extra support for GQ-05. The equipment stays unavailable after finishing. I'm not claiming every defect is closed or that the release is approved.

The earlier [R-4 trial](MAN-007-Confirm-R4-Observation.md) is kept as an observation where the setup had changed. The [restoration supplement](SUP-Restore-Active-E2-Observation.md) has its own limits about the timer and queue. The original inventory, source, student report and presentation are unchanged.
