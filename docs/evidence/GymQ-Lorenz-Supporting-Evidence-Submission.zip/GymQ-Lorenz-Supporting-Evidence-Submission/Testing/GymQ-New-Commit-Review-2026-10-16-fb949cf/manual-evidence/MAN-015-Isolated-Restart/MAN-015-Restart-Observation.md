# MAN-015: report saved across a restart, separate source build (17 Oct 2026)

**Result: Passed, for this one sub-check (one trial): a report survives a restart on a separate source build in the real app.**
**MAN-015 as a whole is still only partially verified.** I didn't test an installer, a clean install, uninstall or reinstall, a self-contained runtime, Windows, or whether other data and deadlines are saved.

## Where everything came from

- Build `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The original repository was clean at HEAD when I checked it after the run.
- App: framework-dependent Release build `source-build/GymQ.Desktop`.
  - apphost SHA-256 `d2911fa4…d8b5`
  - DLL SHA-256 `c7d5cc27…4611`
  - Both match `MAN-015-Preparation.json`.
- Launcher: `ENSE707/Testing/Start-MAN-015.command`, SHA-256 `3c64f619…2659`, which is byte-for-byte the same as `Start-Restart-Check.command`. I used it for both launches.
- Save file: `data/gym-state.json`, set with `GYMQ_DATA_PATH`, with saving turned on and a single window.
- `Launch.log` stayed empty, so there were no errors or other output.
- The Debug app that was already open (PID 3690, using the normal save file) kept running the whole time. I didn't use, quit or change it.

## Timeline (NZDT, 17 Oct 2026)

| Time | What happened | Evidence |
| --- | --- | --- |
| 02:40:27 | Run 1 starts as process PID 10479 from the separate `source-build/`. A fresh save file is created with the starting data, including R-1, a confirmed E3 report. | `ps`; timestamps in `data/` |
| 02:41:35 | As Lorenz (M001) I submit a report on E1 = Treadmill #3. It's saved straight away: R-2, Pending. | `01-Lorenz-Report-Submitted.png`; `pre-restart-store/` |
| ~02:44 | The Staff dashboard shows Pending reports · 1: Treadmill #3, the text below, `R-2 · Lorenz Soriano`. I didn't confirm or reject it. | `02-Staff-Pending-R2-Before-Quit.png` |
| 02:45:05 | I quit run 1 normally. PID 10479 is gone. The save on exit only changes `savedAtUtc`. | `post-quit-store/` |
| 02:46:17 | Run 2 starts as PID 10630 with the same launcher, build and save file. It saves again when it opens: the `.bak` is byte-for-byte the file from after the quit, and only `savedAtUtc` changed. | `after-relaunch-store/` |
| ~02:47 | The Staff dashboard again shows Pending reports · 1: Treadmill #3, the same text, `R-2 · Lorenz Soriano`. The equipment statuses match the screenshot from before. | `03-Staff-Pending-R2-After-Relaunch.png` |

## The test text

The saved and displayed text, both before and after the restart, is `MAN-015-1710: Test only — persistence restart check`.

It has **no full stop at the end**, unlike the text I was meant to type. The source does call `description.Trim()` (`src/GymQ.Core/Services/GymSession.cs:146`), but that only removes spaces at the start and end, not a full stop. So the cause isn't confirmed, and most likely I just didn't type the full stop. I'm not treating this as an app defect. The before and after comparison uses the exact saved text, which didn't change.

## Was there a save warning?

I didn't see a warning, but I didn't take a screenshot of the run 2 Login screen. If the app falls back to running in memory only, `App.axaml.cs` creates `GymSession(seed: false)`, and that session wouldn't have R-1 or R-2. Run 2 showed R-2 and saved the same file again when it opened. Together, that supports run 2 loading this file and not running in memory only.

## Limits

- One local trial, with one report and one restart.
- The logged-in account and the current page aren't saved, so going back to Login on relaunch is expected.
- **The evidence is screenshots only, by my choice.** I did make a screen recording (`Screen Recording 2026-10-17 at 2.40.45 AM.mov`), but it was in a protected macOS temp folder and I chose not to provide it. It wasn't reviewed and isn't part of this evidence. Without a continuous video, the quit and relaunch steps are backed by process IDs, save-file snapshots and hashes, not video frames.
- No automated tests were run again; 253/253 is still a separate result from 16 Oct.
- The frozen inventories are unchanged and still byte-for-byte identical.
