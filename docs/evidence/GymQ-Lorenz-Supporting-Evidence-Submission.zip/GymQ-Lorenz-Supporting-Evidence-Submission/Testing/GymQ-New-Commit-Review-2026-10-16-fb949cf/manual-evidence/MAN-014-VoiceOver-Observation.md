# MAN-014: VoiceOver login and navigation attempt

**Outcome: attempted, but what VoiceOver said (names, roles and states) is UNVERIFIED. MAN-014 as a whole is still partially verified.**

I made an 87.425-second recording in the real app after agreeing to a guided VoiceOver check. The sampled frames show Login → Jayden's Equipment → Profile → Login, with focus and cursor outlines that fit what I said I'd do. These are visual observations only.

The MOV has one audio track, and a WAV made from it is kept. The reviewer couldn't listen to or transcribe the audio with the tools available. When asked what VoiceOver said for Username, Password, LOG IN, Profile and Log out, I answered **"i dont remember"**. I'm not guessing the spoken words from the on-screen text or the source's automation properties. So this is an incomplete assessment. It isn't proof the app failed, and it isn't a passed screen-reader check.

| Time in original video | What I saw |
| --- | --- |
| 0.000s | B starts at a blank Login; A shows Christian's Equipment. E2 and E4 are already Available; E1 and E3 are Out of Service. |
| 9.992s | The Username field has blue focus and a separate rounded double outline, which looks like the VoiceOver cursor I said I'd use. No readable speech text is visible. |
| 19.988s | The username Jayden_Marsh has been typed. The text in the field doesn't tell us what VoiceOver said. |
| 29.988s | The Password field shows hidden characters and has a focus or cursor outline. Its spoken label, role and secure-field announcement are unverified. |
| 39.988s | Password still has focus, with hidden characters. No caption panel is visible. |
| 49.988s | B opens Jayden's Equipment, with an outline around the header avatar. The login visibly works, but I didn't assess the actual LOG IN announcement. |
| 60.000s | Jayden's Equipment is still showing, with the outline on the header avatar. |
| 69.992s | The Profile button in the bottom navigation has an outline; the pointer is somewhere else. No caption panel is visible. |
| 79.992s | Jayden's Profile is open, with the avatar outlined; the existing Demo Time offset shows 3 minutes. No new time skip is seen. |
| 87.225s | B is back at a blank Login. The screen-recording toolbar covers part of the edge. This rough sample doesn't show an actual Log out announcement or focus timing. |

## Evidence kept

- `MAN-014-VoiceOver-Login-Navigation.mov` (recording not included): 18,802,397 bytes; SHA-256 `bd99203f7c31638cb3dc5121e762afbc3744e9c34b8bdddf1e0eeede5d1f44fa`.
- [Structured observations and 10 frame hashes](MAN-014-VoiceOver-Observation.json).
- `MAN-014-VoiceOver-Audio.wav` (recording not included) and `MAN-014-VoiceOver-Audio-Metadata.json` (preparation metadata omitted). The WAV is resampled mono PCM, not an identical copy of the original audio stream. Having audio doesn't confirm what was said.
- The earlier [keyboard evidence](MAN-014-Keyboard-Observation.json) keeps its pass within scope; this attempt is separate evidence.

## Next check (planned at the time)

Turn on VoiceOver's caption panel and record it together with the app. Pause on Username, Password, LOG IN, Profile and Log out so the actual announced text can be checked. [Apple's caption-panel instructions](https://support.apple.com/guide/voiceover/use-the-braille-and-caption-panel-unac078/10/mac/27) explain the setting: Visuals → Panels and Menus → Show caption panel in VoiceOver Utility.

The scaled-layout and high-DPI check and the other keyboard workflows are still Not Run. Which exact app binary was running, the host setup and whether a separate save file was used aren't confirmed. I'm not claiming full accessibility, a usability study, a package test or release approval. The source, original inventory, report and presentation are unchanged.

## Later caption-panel evidence

A separate 01:50:07 recording now confirms the caption text for the controls I checked and shows naming defects. See the [caption follow-up](MAN-014-Caption-Observation.md). This earlier clip is still an incomplete audio assessment.
