# MAN-003: all my manual nudge observations in one place

**There's now evidence for all three nudge replies in the current prototype.** Still Using has before and after screenshots, and the unanswered timeout and End My Session each have a recording of me using the real app.

| Branch | What I found | Evidence |
|---|---|---|
| Still Using | The before and after screenshots show Christian's session carrying on and Jayden keeping his place in the queue, as expected. | [Still Using observation](MAN-003-StillUsing-Observation.md) |
| No response | Passed for one real-time trial with local windows. The session ended by itself after about 120 real seconds, with a clear "nudge not answered" reason, and Jayden got the offer. | [Real-time timeout observation](MAN-003-Realtime-Timeout-Observation.md) |
| End My Session | Passed for one trial using the button in the pop-up. Christian goes back to Equipment, and Jayden gets the rack and claims it. | [End response observation](MAN-003-EndMySession-Observation.md) |

## Limits on this result

This covers **the three replies in the current two-minute prototype**. It isn't full verification against the original requirements. **The older AC03 one-minute timing is still unresolved**, and I'm not assuming the lecturer approved the difference.

The local source build is `fb949cf7888976f1b51a39195b5a8dd84486c9ae`, but the recordings don't show which app binary or package was running. My observations in the real app and the 253-test automated run are separate evidence. I operated the app; the observations were assessed from the supplied evidence. The exact OS version and whether a separate save file was used haven't been independently confirmed.

The two windows are one local process. The full five-minute cooldown, repeated timing under load, delivery to separate devices, package acceptance and first-time usability aren't covered here. No human release approval was given. Earlier notes that say "Finished" was still to be tested describe the situation at that time; this summary shows the later progress.

The original 16-case inventory is unchanged. `Manual_Check_Progress.csv` has the current progress, and no other full manual case is automatically marked Passed because of this clip.

## Next manual case (planned at the time)

MAN-004: the original claim deadline runs out without anyone claiming, and the next person in the FIFO queue gets the offer. This needs one owner and two queued accounts, a real-time recording and a clear note of which account is in which window. It hadn't been run yet. The latest recording ends with Jayden using the rack, ready for Christian and then Lorenz to queue in a controlled order.
