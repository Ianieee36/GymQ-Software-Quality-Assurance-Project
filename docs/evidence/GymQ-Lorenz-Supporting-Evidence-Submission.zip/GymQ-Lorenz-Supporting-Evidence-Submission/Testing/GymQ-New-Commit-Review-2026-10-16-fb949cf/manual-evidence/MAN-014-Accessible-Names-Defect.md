# MAN-014 finding: technical type names instead of proper control names

**Status: seen and still open.** It hasn't been fixed or retested. This is a finding inside MAN-014, not an extra original manual case. No severity or priority has been formally given yet.

## What should happen and what actually happens

The original MAN-014 expects controls to be reachable and labelled. When an equipment image has focus, it should say which equipment it is and what it does. The Equipment and Profile buttons in the bottom navigation should have clear names that are different from each other.

| Control | What the VoiceOver caption actually said | Time in video | Evidence |
| --- | --- | --- | --- |
| Treadmill image button | Avalonia.Controls.Image, button, group | 66.850s | [Frame from the video](MAN-014-Caption-Image-Name-Defect.png) |
| Equipment in bottom navigation | Avalonia.Controls.StackPanel, button, group | 82.383s | [Frame from the video](MAN-014-Caption-Equipment-Nav-Name-Defect.png) |
| Profile in bottom navigation | Avalonia.Controls.StackPanel, button, group | 86.688s | [Frame from the video](MAN-014-Caption-Profile-Nav-Name-Defect.png) |

From these captions, you can't tell the two bottom buttons apart, and the image caption doesn't say which equipment it is or what it does. That makes them hard to identify with a screen reader. I'm not claiming a study with blind users or a measured impact. Navigation still gets to Profile in this run, so this is a naming problem, not proof that Profile won't open.

## How to reproduce it (from the recorded run)

1. Turn on VoiceOver and its caption panel, then log in as a member. In my run, I end up signed in as Jayden.
2. Move the VoiceOver cursor to the Treadmill equipment image and check its caption.
3. Move to the Equipment and Profile buttons in the bottom navigation and check each caption.
4. Compare them with the correctly named header avatar ("Open profile, button, group") and Log out ("Log out, button").

The physical key presses weren't logged. This describes the focus route I saw, not a certified key-by-key replay.

## Checking the source, and a suggested fix

Source checked: `fb949cf7888976f1b51a39195b5a8dd84486c9ae`, with a clean repository. The hash of the app binary that was running and the host OS version aren't confirmed.

- `src/GymQ.Desktop/Views/MainWindow.axaml`, lines 63–74: the Equipment and Profile buttons contain a StackPanel and visible text, but there's no explicit accessible name or label linked to these buttons.
- `src/GymQ.Desktop/Views/EquipmentView.axaml`, lines 24–28: the image button contains an Image, and the equipment name is a separate text element next to it.
- `src/GymQ.Desktop/Views/MainWindow.axaml`, line 42: the header avatar has an explicit name, "Open profile", which matches the useful caption I saw.

**My best guess:** when there's no accessible name, the app falls back to showing the type name of the content inside the button. I didn't confirm exactly how the framework does this. A suggested fix is to give the navigation buttons and equipment image buttons clear, explicit accessible names, then retest with VoiceOver in the real app. This evidence review doesn't approve or make any change to the product.

## Retest still needed

After a fix that's been separately approved, check that:

- Equipment and Profile have different names;
- each equipment button has a name for that machine and what it does;
- keyboard focus and activation still work;
- the header, login and logout labels haven't broken.

Also review the remaining controls, pop-ups, selectors, staff pages, focus recovery and the scaled layout. How clearly it sounds, and how the password field behaves with a screen reader, aren't covered by this caption-only result.

[Observation and limits](MAN-014-Caption-Observation.md) · `MAN-014-VoiceOver-Caption-Panel.mov` (recording not included)
