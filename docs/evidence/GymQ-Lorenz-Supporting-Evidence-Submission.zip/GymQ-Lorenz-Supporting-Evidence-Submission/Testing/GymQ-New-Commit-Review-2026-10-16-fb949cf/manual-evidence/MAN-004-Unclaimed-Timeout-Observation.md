# MAN-004: an offer that times out without being claimed

**Result for what I tested: Passed for one trial in the real app using local windows. Part of the recording is covered by another window, and I've noted where.** In this recording from 16 October 2026, which I made while using the app, Christian's offer runs out after about two real minutes, Christian is removed, and the next person in the FIFO queue, Lorenz, gets the rack and claims it.

| Time in video | What I saw |
|---|---|
| 2.500 s | Jayden is using Squat Rack #2; Christian is first in the queue and Lorenz second. The pointer is over Jayden's End Session button. |
| 2.650 s | Christian gets YOUR TURN / CLAIM MACHINE with a 01:59 countdown. Jayden is back on Equipment. |
| 23.308 s | Device B is now signed in as Lorenz, still #2 behind Christian. Christian's original offer shows 01:39. |
| Roughly 28–54 s | Another window covers most of the app. I didn't measure exactly when it starts and stops. |
| 55.958 s | The app is visible again: Christian has 01:07 left and Lorenz is still second. The countdown matches the original deadline. |
| 122.433 s | Christian's offer is still showing at 00:00; Lorenz is still second. |
| 123.450 s | Christian sees "You're no longer queued." Lorenz gets YOUR TURN for the same rack, with a new 01:59 claim countdown. |
| 133.605 s | Lorenz has claimed and his Squat Rack #2 session starts at 00:00. Christian sees Lorenz as the current user, and the queue is empty. |

From the first visible offer to the first visible handover is **120.800 seconds**. The handover happens between the last "still waiting" frame at 122.433 s and the first "done" frame at 123.450 s, a gap of about 1.017 seconds. That supports **about 120 real seconds**; it isn't a precise measurement of the backend. The source refreshes every second and rounds the countdown down, which explains why it starts at 01:59 and shows 00:00 briefly before the handover.

Device B switches from Jayden to Lorenz after Jayden finishes, and Christian stays signed in on Device A. The countdown before and after the covered part matches the same original deadline. The recording doesn't show the controls the whole time during that part, so I can't say for certain nothing was pressed then.

## Evidence and limits

- `MAN-004-Unclaimed-Timeout.mov` (recording not included), 138.058 seconds; SHA-256 `4da07d95f462bbf424a9c8b4f3d0a2b4e6bcb3a1ec86d987886a77303b116032`.
- [Timestamped record and frame hashes](MAN-004-Unclaimed-Timeout-Observation.json). The seven PNGs are frames taken straight from the video, with nothing on screen changed.
- Source checked: `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The recording doesn't prove which app binary or package was running.
- What the source says should happen: `QueueService.cs` expires an offer after two minutes and tells the next person in the FIFO queue; `ClaimOverlay` works out the deadline from when the notification was first sent; signing out clears the screen for that account without resetting anyone's place in the queue.
- The two local windows share one process. This is one functional trial. It isn't evidence for separate physical devices, installing a package, load or performance, or first-time usability. I didn't try claiming late.
- The clip doesn't confirm whether a separate save file was used or the host OS version. No human release approval is implied.

The original manual inventory, source code, final report and slides weren't changed. The current result is recorded in [Manual_Check_Progress.csv](Manual_Check_Progress.csv). The recording ends with Lorenz already using E2, which works as the setup with an active member for the next MAN-005 report-selector check.
