# MAN-003: unanswered nudge in real time, one trial in the real app

**Result for what I tested: Passed for the unanswered-nudge branch under the current two-minute rule.** At the time, MAN-003 as a whole was only partly done, because the **END MY SESSION** reply still needed evidence.

I ran the real app and recorded a 146.558-second screen video on 16 October 2026 (Pacific/Auckland). The original video timestamps, extracted frames and current source behaviour were reviewed. This is evidence from me using the real app, not a headless test setup. The recording doesn't prove which app binary was running or that a package was accepted. The expected behaviour was checked against the source at `fb949cf7888976f1b51a39195b5a8dd84486c9ae`.

## What I saw

| Video time | What's on screen |
|---|---|
| 0.488s | Christian is using Squat Rack #2; Jayden is first in the queue; no nudge shown yet. |
| 0.680s | Christian gets the nudge, starting at 01:59. Jayden sees that his nudge was sent. |
| 120.425s | Still no reply to the nudge; the countdown is at 00:00. |
| 121.433s | Christian sees Session complete, with a clear "nudge not answered" reason and a duration of 05:15. Jayden gets YOUR TURN and CLAIM MACHINE for the same rack, with a 01:59 claim countdown. |

From the nudge appearing to the handover appearing: **120.753 seconds**. That fits a 120-second deadline plus the app's refresh and redraw cycle. Going by the frames I checked, the time from request to visible handover is roughly **119.745–120.945 seconds**. The end point is only accurate to about **1.008 seconds** because of the frame spacing, so this isn't a precise internal service time. Starting at 01:59 and ending at 00:00 fits a countdown that rounds down to whole seconds.

Checkpoints every ten seconds show the countdown moving in step with the video time. In the frames I checked, there's no reply and no demo-time skipping. A chat window covers the app after 125.758s, but that's after the timeout and handover had already appeared, and the last frame confirms the same result.

## What this does and doesn't cover

- The two local windows share one process, so this doesn't show separate devices syncing.
- One trial doesn't show a load target, the full five-minute cooldown, first-time usability or release readiness.
- The running binary or package SHA, the exact OS version and whether a separate save file was used can't be confirmed from this recording.
- The older AC03 says one minute. This result confirms the current two-minute behaviour I saw. It doesn't resolve that conflict and isn't lecturer approval.
- The earlier demo-time attempt is separate, simulated evidence.
- Still Using already had before and after evidence. Next step at the time: test **END MY SESSION** with a fresh nudge.
- The original manual inventory, report, presentation and project source weren't changed. No release approval is implied.

## Evidence kept

- Video: `MAN-003-Realtime-Timeout.mov` (recording not included), SHA-256 `1608bcfecc275990fdf9a955cf5a374daa2ae4bd3db09385502751a93a402319`. The original was copied unchanged.
- Five timestamped PNG frames with exact metadata and hashes: `MAN-003-Realtime-Timeout-Observation.json`. The PNGs are frames taken straight from the video, with nothing on screen changed.
