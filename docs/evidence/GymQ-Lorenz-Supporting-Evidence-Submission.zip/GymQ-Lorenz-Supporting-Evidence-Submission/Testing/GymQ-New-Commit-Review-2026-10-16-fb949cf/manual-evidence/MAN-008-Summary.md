# MAN-008: sessions and getting back to a claim

**The claim-recovery path passed in one trial I ran in the real app with local windows. MAN-008 as a whole is only partially verified.** I didn't test whether the member's ended session, with its duration and end reason, shows up after the handover.

I used the app in one continuous 128.190-second recording. Device A switches Christian → Lorenz → Christian to set up the FIFO order, and Device B switches Gym Staff → Jayden → Lorenz. I used E4 (Recumbent Bike) as the claimant's existing session instead of E1, the example in the runbook. These are two local windows sharing one process.

| Time in original video | What I saw |
| --- | --- |
| 1.725 s | Christian starts E4, showing 00:00 / 30:00. |
| 30.988 s | Lorenz is #2 behind Christian; Jayden owns E2 (Squat Rack #2). |
| 70.913 s | Christian's queue and Jayden's E2 session are visible; the pointer is on Jayden's End Session. |
| 71.722 s | Christian gets the E2 offer at **01:59**. Claim is greyed out, with a note about his active session and a **Go to Current Session** button. Jayden is back on Equipment with no claim offer. |
| 78.908 → 79.892 s | The recovery button takes Christian to his E4 session at 01:18. The offer doesn't block the session screen. |
| 89.917 s | Christian's E4 is at 01:28; the pointer is on End Session. |
| 91.000 s | The E2 offer comes back by itself at **01:40**, with Claim enabled. E4 is Available. |
| 93.483 → 93.808 s | After he presses Claim, Christian's new E2 session starts at 00:00. |
| 110.972 s | Lorenz is still next, and Christian correctly shows as the current E2 owner. |
| 125.997 s | Both Equipment views show E4 Available; Christian owns E2 and Lorenz is #1 of 1. |

## The original countdown

The 01:59 reading at 71.722 s and the 01:40 reading at 91.000 s both point to about the same deadline, around **191 s into the recording**. There are 19.278 seconds between the two readings, and the displayed time drops by 19 seconds. That fits within the one-second display and refresh precision. The offer wasn't visibly reset to a fresh two minutes. I'm not claiming the exact backend deadline precision.

## What's still missing, and the limits

Christian's E4 duration is visible **before** he finishes it. After he claims E2, the recording doesn't show the ended E4 duration or why it ended. Seeing the duration before it ended, and then a different current session, doesn't prove the history is kept. So this part of FR008/AC08 stays unverified.

E4 showing Available while Christian owns E2 supports him having only one active session in this flow. I didn't look at backend session IDs or every possible path. This isn't a result for separate devices, usability, packages or release approval. The exact running binary hash, whether a separate save file was used and the host OS version are still unverified.

The source HEAD I checked is still `fb949cf7888976f1b51a39195b5a8dd84486c9ae`, with a clean checkout. The 253/253 automated result is a separate run from 16 October; no automated tests were rerun for this clip.

## Evidence

- `MAN-008-Claim-Recovery.mov` (recording not included), 25,735,386 bytes; SHA-256 `5469195fd25a34d52277407d28f23f531a0af1acfea2e34acf612bd7699e4dbe`.
- [Structured observation, timestamps and 13 original-frame hashes](MAN-008-Observation.json).
- [Original offer](MAN-008-Original-Offer.png), [current session](MAN-008-Current-Bike.png), [offer coming back](MAN-008-Resumed-Offer.png), [successful claim](MAN-008-Claimed-Rack.png), [member still next in the queue](MAN-008-Lorenz-Next.png).

## Using the same trial for other cases

**MAN-002:** The same trial supports a pass for next-user notification in the real app, within its scope. Jayden ends normally, and Christian gets the right E2 offer, while Jayden gets no claim prompt during what I watched. The active-session restriction is on purpose, and the recovery makes the offer usable. This is the same evidence used again, not another run, and it doesn't prove delivery to another device.

**MAN-001:** The same trial only supports equipment selection working and the #1/#2 FIFO display. I didn't measure the click-to-position time, a planned number of samples or performance under normal load here. The timing criterion is still open.
