# MAN-014: VoiceOver caption panel follow-up

**Result: mixed.** The names for login, the header profile button and logout that I checked are correct. The checks for proper names on the bottom navigation and the equipment image **failed**. MAN-014 as a whole is still partially verified, with naming defects found.

This time my 01:50:07 recording includes readable VoiceOver captions, so it shows the actual text VoiceOver generated. I didn't assess how clearly it sounds. The earlier audio-only attempt is kept as an incomplete review and hasn't been relabelled.

| Time in video | Control or state | Caption, or what I saw |
| --- | --- | --- |
| 6.983s | Username | Username, text |
| 9.825s | Text-Field-Hint | You are currently on a text field, inside of a window. |
| 14.688s | Password | Password, text |
| 20.725s | Login | LOG IN, button |
| 29.413s | Initial-Login-Rejected | You are currently on a button, inside of a window. To click this button, press Control-Option-Space. |
| 39.708s | Username-Revisited | Lorenz_Soriano, Username, text |
| 53.383s | Login-Second-Attempt | LOG IN, button |
| 60.825s | Logged-In | B is on Jayden's Equipment after a later login; the exact physical inputs weren't logged. |
| 64.050s | Header-Profile | Open profile, button, group |
| 66.850s | Image-Name-Defect | Avalonia.Controls.Image, button, group |
| 72.650s | Start-Session | Start Session, button |
| 82.383s | Equipment-Nav-Name-Defect | Avalonia.Controls.StackPanel, button, group |
| 86.688s | Profile-Nav-Name-Defect | Avalonia.Controls.StackPanel, button, group |
| 89.892s | Profile-Opened | Avalonia.Controls.StackPanel, button, group |
| 95.388s | Logout | Log out, button |
| 101.750s | Returned-To-Login | B goes back to a blank Login; the caption still shows the previous generic button hint, so I'm not assuming a new focus announcement. |
| 103.992s | Final-Login | Final blank Login; the screen-recording toolbar is visible at the edge. |

The first Lorenz_Soriano login is rejected. Later in the recording I use Jayden_Marsh and get to Equipment, Profile and logout. I don't know why the first login was rejected or whether its error was read out. Don't describe this as one uninterrupted, successful Lorenz login.

## Evidence

- `MAN-014-VoiceOver-Caption-Panel.mov` (recording not included): 104.063 seconds; 5,304,284 bytes. SHA-256 `72812e70b6a2f4a38f5767ab468b20ebc6a06e4ad2846d95b8f09244382d07ec`.
- [Structured observations and 17 frame hashes](MAN-014-Caption-Observation.json).
- [Naming defect record](MAN-014-Accessible-Names-Defect.md).

The caption names Username and Password are confirmed, and their role is shown as "text". Whether the password field behaves properly as a secure field, and whether the password could be revealed, aren't established and I'm not assuming either way. The current source sets PasswordChar to a bullet and the accessible name to Password.

The scaled-layout and high-DPI check, pop-ups, selectors and staff-page accessibility are still Not Run. Which exact app binary or package was loaded and the host setup aren't verified. Two local windows don't show support for separate devices. The Profile view already has a Demo Time offset of 3 minutes, so this clip isn't timeout evidence. The source, original inventory, final report and presentation are unchanged.
