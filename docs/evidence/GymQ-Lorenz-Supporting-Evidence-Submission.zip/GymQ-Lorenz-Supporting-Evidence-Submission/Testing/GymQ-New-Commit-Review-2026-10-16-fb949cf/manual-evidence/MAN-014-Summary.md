# MAN-014: keyboard route and VoiceOver follow-up

**The earlier keyboard route passed, within its scope. MAN-014 as a whole is currently partially verified, with screen-reader naming defects found.**

The later caption-panel recording confirms the names for Username, Password, LOG IN, the header "Open profile" and Log out. But the bottom Equipment and Profile buttons, and an equipment image I checked, show generic technical type names, so those label checks failed. See [latest caption evidence](MAN-014-Caption-Observation.md) and [open naming finding](MAN-014-Accessible-Names-Defect.md).

I made this recording in the real app after being told to click once to set focus and then use Tab, Shift+Tab and the keyboard to activate things. The physical keys aren't shown or logged. The visible focus, where the navigation ends up, and the pointer being away from the controls that were activated all support that I used the keyboard, but the exact keys can't be certified from screen images alone.

| Time in original video | What I saw |
| --- | --- |
| 0.975s | Username has a blue focus outline. |
| 14.988s | Password has blue focus; the username Jayden_Marsh has been typed. |
| 22.647s | I go back to Username and it's selected. |
| 29.580s | I go back to Password and it's selected. |
| 31.730s | LOG IN shows a white focus rectangle. |
| 32.938s | Jayden's Equipment screen opens, which is correct. |
| 42.275s | The Profile button in the bottom navigation has a white focus rectangle. |
| 46.808s | Jayden's Profile opens. |
| 50.758s | Log out has a white focus rectangle. |
| 51.950s | The blank Login screen comes back, and the signed-in header and navigation are gone. |

I didn't get stuck anywhere on this route. This doesn't show that every control works with the keyboard, or that going backwards through everything works. Staff pages, report selectors, pop-ups and focus recovery in those workflows are separate checks.

## Evidence and what's still left

- `MAN-014-Keyboard-Login-Navigation.mov` (recording not included): 60.287s, 3,339,217 bytes; SHA-256 `c86f5739972cf78e8fc2f829ac661373be54e211c8aab590ab9ec66a74614b0b`.
- [Structured record and 11 frame hashes](MAN-014-Keyboard-Observation.json).
- [Login focus](MAN-014-Login-Button-Focus.png), [Profile focus](MAN-014-Profile-Nav-Focus.png), [Logout focus](MAN-014-Logout-Focus.png), [back to login](MAN-014-Returned-To-Login.png).

**There are now three separate pieces of VoiceOver-related evidence:** the earlier keyboard recording; the 01:26:41 attempt, which kept the audio but couldn't be fully assessed; and the 01:50:07 recording with a readable caption panel. The latest clip shows the caption text generated for the controls I checked and reveals the naming defects. It doesn't show how clearly it sounds, how the password field behaves with a screen reader, or full accessibility.

**The scaled-layout and high-DPI check is still Not Run.** Other keyboard and assistive-technology workflows, including pop-ups, selectors and staff pages, haven't been run. Labels in the source don't replace evidence from the running app. The earlier [attempt record](MAN-014-VoiceOver-Observation.md) is kept as history; the current status comes from the [caption follow-up](MAN-014-Caption-Observation.md).

The source HEAD is still clean at `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The Login, MainWindow and Profile views I checked have the matching fields, buttons and commands. Which exact app binary or package was running, whether a separate save file was used, the host OS version and the keyboard settings are still unverified. I'm not implying any new automated run, a first-time-user study or release approval.

E2 is already Available at the start of the recording; the previous session and queue changed during a part that wasn't recorded. This clip doesn't show why or when that session ended. The Profile's existing Demo Time offset is 3 minutes in both the first and last Profile frames I checked, so no extra time was added in between. I'm not using this clip as timeout evidence.

The project source, original inventory, student report and presentation are unchanged.

## Skipped at my request

After the caption review, when the scaling check was suggested, I asked to skip it and move on. The scaling check is recorded as **NotRun (skipped at my request)**. There's no extra run or successful result for it. MAN-014 stays **partially verified, with naming defects found**, and the naming findings stay open. The idea that it's a Mac-specific issue is only a guess, not a confirmed explanation or a waiver.
