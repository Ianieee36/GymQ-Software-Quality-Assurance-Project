# MAN-006: staff reviewing reports, and what members then see

**Staff decisions in the real app: Passed for one rejection trial and one separate confirmation trial.** My recordings show the right report chosen each time, the pending list changing correctly, and the matching equipment status in both the staff and member windows. **I didn't try a member directly reviewing a report by hand.** The existing automated guard tests are listed separately below.

| Branch | What I saw | Evidence from the real app |
|---|---|---|
| Two-report setup | R-2 is the belt-noise test report and R-3 is the safety-stop test report. Both are for Treadmill #3 and list Lorenz. Pending count is 2. | `MAN-006-Two-Pending-Reports-Baseline.png` |
| Reject R-2 | Pointer on R-2's Reject at 1.633 s; by 2.772 s the count is 1 and only R-3 is left. The treadmill stays Available in both windows. | `MAN-006-Reject-R2.mov`, `MAN-006-Reject-R2-Observation.md` |
| Confirm R-3 | Pointer on R-3's Confirm fault at 1.983 s; by 2.992 s the count is 0 and "All caught up. No reports waiting for review." appears. | `MAN-006-Confirm-R3.mov`, `MAN-006-Confirm-R3-After.png` |
| What the member sees | The treadmill becomes Out of Service with "Staff review completed" and no Start Session button. Staff sees Out of Service too, with Mark as available. | `MAN-006-Confirm-R3-After.png`, `MAN-006-Confirm-R3-Retained-State.png` |

For a rejection, the feedback is the list and count changing. A confirmation also shows the empty-list message and the equipment status change. I'm not claiming a separate "review done" pop-up or a visible Rejected/Confirmed label.

## Separate automated authorisation evidence

These four results **Passed** in the existing `../TestResults/fb949cf.trx`, from the separate automated run of source `fb949cf7888976f1b51a39195b5a8dd84486c9ae`:

- `ReviewFaultReport_NonStaffMember_ThrowsUnauthorizedAccessException`: the service rejects a review from someone who isn't staff.
- `StaffReview_StillRejectsMemberIdentity`: the coordinator rejects a review from a member.
- `DemoLogin_RoutesToCorrectDashboard_AndLogoutRestoresGuard ("M002")`.
- `DemoLogin_RoutesToCorrectDashboard_AndLogoutRestoresGuard ("M003")`.

The last two are headless navigation checks. The test code is in `tests/GymQ.Tests/Original/FaultReportServiceTests.cs`, `tests/GymQ.Tests/Integration/GymSessionIntegrationTests.cs` and `tests/GymQ.Tests/UI/LoginTests.cs`. The exact test names, results and times are kept in `MAN-006-Confirm-R3-Observation.json`. I'm not relabelling any automated result as human security testing, and I'm not claiming production-level login security.

## Where it came from, and the limits

- Original confirmation recording: 10.598 seconds; SHA-256 `33c3535d7edd3d583d41bb3a5ea2d659a247db51a2dbd8328d8b01a4d83ef049`.
- Four frames taken straight from the original video, with timestamps and hashes, are saved in `MAN-006-Confirm-R3-Observation.json`. The rejection has its own unchanged recording and four frames.
- Device A is Gym Staff and Device B is Lorenz. These are local windows sharing one process. The recordings don't prove the running app binary or package SHA, the OS version or whether a separate save file was used.
- **Squat Rack #2 is already Available at the start of the confirmation clip.** Its earlier session ended between recordings, and the clip doesn't show why. That change shouldn't be put down to the treadmill fault being confirmed later. If MAN-007 needs someone actively using the machine, set up a fresh session.
- Nobody was shown queued for E1 in this trial, so it doesn't complete the queue-cancellation or affected-member message checks. Those belong to MAN-007.
- This doesn't cover Mark as available, installing a package, delivery to a separate physical device, a usability study, a raw save-file check or release approval.

The full manual authorisation check still hasn't been done by hand; the decisions in the real app and the separate automated guards are different kinds of evidence. The original inventory, source, report and slides are unchanged. See [Manual_Check_Progress.csv](Manual_Check_Progress.csv).
