# MAN-001: queue response in the real app, three local samples

**Result for what I tested: all three recorded local queue joins pass the right-equipment, FIFO and two-second checks. Acceptance under normal gym load is still unverified.**

Christian owns E2 (Squat Rack #2). Jayden leaves the queue and joins again behind Lorenz, and each time he correctly goes back to #2. Device A is Christian and Device B is Jayden in both recordings. Lorenz stays first.

The first clip records two new joins. It starts with Jayden already queued, and I didn't count that starting state as a trial. The later clip gives the third new join. The original plan used Lorenz joining in first place; I've kept a note that the member and position actually tested were different.

| Recorded trial | How the join was started | Last checked frame with no click marker | Click marker | Correct E2/#2 shown | Marker to position | Cautious time window | Local result |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Equipment-list card | 19.142s | 19.938s | 20.088s | about 0.15s | below 0.95s | Passed |
| 2 | Equipment-list card | 32.350s | 32.400s | 32.558s | about 0.16s | below 0.21s | Passed |
| 3 | Equipment detail | 6.697s | 7.638s | 7.722s | about 0.08s | below 1.03s | Passed |

Times are counted from the start of each original recording. Trials 1–2 are from the 00:40:48 clip and trial 3 is from the 00:48:31 clip. That's **two joins from the card and one from the detail page**, not three repeats with the same button. I'm not claiming an average, a percentile or a worst case.

## How to read the timings

The times come from the actual timestamps in the original videos, not from requested extraction times or an assumed constant frame rate. The cautious windows start at the last checked frame without a click marker and end at the first checked frame with the right position. They include the gap between sampled frames; the gaps around the click marker are about 0.797s, 0.050s and 0.942s respectively.

These are screen-recording observations. I didn't measure the macOS click-marker delay or the exact moment the physical click happened. The local results meet the two-second check in these observations, but they don't measure backend speed or performance under real gym load. The setup has four equipment cards, one E2 owner, one person waiting and one person repeatedly joining, in two local windows that share one process. No normal-load or stress setup, host resource measurements or tests on physical devices were done.

## Evidence kept

- `MAN-001-Queue-Response-Trials.mov` (recording not included): 45.005s, 7,569,111 bytes; SHA-256 `b632fd852b5bfe46c8e30d95295f899edb2b530f28cd5a07f9e4e345e2a1f333`.
- [Trials 1–2 record at that point, with 11 frame hashes](MAN-001-Observation.json). Its two-out-of-three assessment is about that first clip; it links to the later follow-up.
- `MAN-001-Queue-Response-Trial3.mov` (recording not included): 15.230s, 3,418,251 bytes; SHA-256 `d952553cdc016e496a32c2166f6d44f3970a60266527a510f1b699f4636a4c5e`.
- [Trial 3 observation](MAN-001-Trial3-Observation.md), [structured record with seven frame hashes](MAN-001-Trial3-Observation.json).
- [Trial 1 position](MAN-001-Trial1-Position.png), [trial 2 position](MAN-001-Trial2-Position.png), [trial 3 detail page](MAN-001-Trial3-Detail-Route.png), [trial 3 click](MAN-001-Trial3-Click-Marker.png), [trial 3 position](MAN-001-Trial3-Position.png).

The records for the first two local trials are kept. The planned three-sample local set is complete, with the account and button differences noted above. NFR001 acceptance under normal load is still unverified; these small observations don't waive it.

## Current scope

The source I checked is clean at `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The exact hash of the running app, whether a separate save file was used, and the host OS and hardware aren't confirmed. The 253/253 automated result is a separate, earlier run. The source, original inventory, final report and presentation weren't changed, and I'm not claiming package acceptance or a release approval.

Last setup I saw: Christian's E2 session at 23:19 with 06:41 left; Lorenz #1 and Jayden #2. Check the setup again later, because the timers keep running.
