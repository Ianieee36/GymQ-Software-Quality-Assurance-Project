# Extra check: restoring E2 while its member still has access

**What I saw:** Staff restores Squat Rack #2 from Out of Service to In Use. Jayden's equipment card changes to "Your session is active" and still has View Session. **Whether the timer carried on, and whether the cancelled queue stayed cancelled, are still unverified.** This extra check doesn't complete MAN-007.

| Time in original video | What I saw |
|---|---|
| 0.000 s | E2 is Out of Service in both the staff and member views; Jayden still has View Session. |
| 1.780 s | The pointer is on staff's Mark as available for E2. |
| 2.988 s | E2 is In Use in both views; Jayden's card says Your session is active. |
| 3.997 s | Still the same; the other equipment states and the pending count of 0 haven't changed. |

The clip doesn't show a session timer, a session ID or a queue list. So from this clip alone, don't assume the restore kept the elapsed time, kept the exact same backend session, or avoided bringing back cancelled queue entries.

`SUP-Restore-Active-E2.mov` (recording not included): 5.038 seconds, SHA-256 `41ddccc4f3c6331e67fff45240b48af31f21f7c99105518847e9a6a84239da9a`. Four frames taken straight from the video, with preservation metadata: [observation JSON](SUP-Restore-Active-E2-Observation.json).

The source build reviewed is `fb949cf7888976f1b51a39195b5a8dd84486c9ae`; which exact app binary was running isn't confirmed. The two local windows share one process. I'm not implying package acceptance, a usability result or release approval. The original inventory, project source, report and slides are unchanged.
