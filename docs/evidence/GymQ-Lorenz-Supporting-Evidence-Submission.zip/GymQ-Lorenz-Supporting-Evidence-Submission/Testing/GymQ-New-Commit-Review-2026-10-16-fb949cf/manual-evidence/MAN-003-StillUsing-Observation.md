# MAN-003: "Still using" reply, from screenshots

I took these screenshots during the guided manual testing on 16 October 2026 (Pacific/Auckland). The images were reviewed separately from operation of the app. The images don't show which commit was being tested. The expected behaviour was checked against `fb949cf`.

**What this sub-check shows:** the before and after screenshots match what should happen when someone answers Still using. Christian gets the right pop-up for the rack. Afterwards his session keeps going and Jayden is still first in the queue. The later image shows no nudge pop-up and the cooldown still running.

**MAN-003 as a whole wasn't finished at this point.** There was no evidence yet for the END MY SESSION reply or for a real 120-second deadline with no reply. You also can't tell from two still images whether the full cooldown is enforced or how fast the app responds. No release approval is recorded, and the original inventory is unchanged.

- Before: `MAN-003-StillUsing-Before.png` (time in the file name: 21:15:52).
- After: `MAN-003-StillUsing-After.png` (time in the file name: 21:16:18).
- The exact original paths and SHA-256 hashes are in `MAN-003-StillUsing-Observation.json`.
