# MAN-003: END MY SESSION reply, tested in the real app

**Result for what I tested: Passed for one nudge reply and handover trial.** I recorded a 22.215-second video on 16 October 2026 (Pacific/Auckland). Visible events were reviewed using frames extracted from the original video. The video is kept unchanged.

| Time in video | What I saw |
|---|---|
| 0.000s | Christian is using Squat Rack #2; Jayden is first in the queue. |
| 3.000s | Christian gets the nudge. The pop-up shows 01:59, and Jayden's 120-second "sent" message is visible. |
| 5.983s | The pointer is on the highlighted END MY SESSION button in the pop-up; 01:57 left. |
| 6.908s | Christian goes back to Equipment. Jayden gets YOUR TURN / CLAIM MACHINE for the same rack. |
| 15.367s | Jayden has claimed and his rack session starts at 00:00; Christian sees In Use / Join Queue. |
| 22.000s | Jayden is still on it at 00:05. |

The reply happens well before the timeout, and the successful claim afterwards confirms the machine passed to Jayden. I'm not claiming a precise click-to-screen time. A chat window briefly covers part of the video after the handover and before the claim, but the reply and the claimed state are both visible.

**Correction to earlier guidance:** In the current code, END MY SESSION closes the nudge on purpose and takes Christian to Equipment (`OverlayViewModels.cs:51–52`). It doesn't have to leave a "Session complete" page on screen. `NudgeResponse` and the detail text 'You confirmed you were finished' are what the source says should happen; they aren't visible in this clip.

## Evidence and limits

- `MAN-003-EndMySession.mov` (recording not included), SHA-256 `501c5d124d01dcfb5b2b052b9ac0a5efffbdc3a9181566a91e248e8275a47a73`.
- Five PNG frames taken straight from the video, with timestamps and hashes: `MAN-003-EndMySession-Observation.json`.
- The expected behaviour was checked against the source at `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The recording doesn't prove which app binary or package was running.
- The two local windows share one process. This isn't evidence for separate devices, installing a package or first-time usability.
- The older AC03 one-minute wording is still an open difference. The current two-minute behaviour and this reply path aren't a lecturer waiver or a release approval.
- The full five-minute cooldown and any load or performance limits weren't measured.

See [MAN-003-Summary.md](MAN-003-Summary.md) for all three branches together. The original manual inventory and older dated evidence are unchanged.
