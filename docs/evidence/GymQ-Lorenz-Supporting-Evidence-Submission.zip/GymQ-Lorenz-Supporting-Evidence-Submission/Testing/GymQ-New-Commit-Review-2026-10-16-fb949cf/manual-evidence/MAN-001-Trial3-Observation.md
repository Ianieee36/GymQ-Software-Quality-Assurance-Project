# MAN-001: third local queue-join trial

**Result for what I tested: Passed.** Jayden leaves E2's queue, opens the Squat Rack #2 detail page and joins again. He goes back to #2 behind Lorenz #1, and Christian is still the one using the machine.

This makes three local queue-join samples across two recordings. The third one uses **Join on the equipment detail page**, while the first two used **Join on the Equipment card**. So they aren't three identical benchmark repeats.

| Time in original video | What I saw |
| --- | --- |
| 0.000 s | Christian on E2 at 23:04; Lorenz #1, Jayden #2. |
| 1.233 s | Jayden has left; Equipment shows one person waiting. |
| 4.000 s | E2 detail page: In Use, one waiting, Join Queue. |
| 6.697 s | Last checked frame with no click marker. |
| 7.638 s | Click ring over Join Queue on the detail page. |
| 7.722 s | Correct E2 queue position: Jayden #2 behind Lorenz #1. |
| 13.713 s | Queue still correct; Christian's session at 23:18. |

From the visible click marker to the correct position: **about 0.08s**. From the last frame without a marker to the correct position, measured cautiously: **1.025s (below 1.03s)**. The bigger number includes a gap of about 0.942s caused by the variable frame rate. This supports the two-second check for this one recorded local sample. It doesn't measure true backend or input speed, or performance under normal load.

`MAN-001-Queue-Response-Trial3.mov` (recording not included): 15.230s, 3,418,251 bytes; SHA-256 `d952553cdc016e496a32c2166f6d44f3970a60266527a510f1b699f4636a4c5e`.

[Structured record with seven original-frame hashes](MAN-001-Trial3-Observation.json). [Summary of all three trials](MAN-001-Summary.md).

The source HEAD is still `fb949cf7888976f1b51a39195b5a8dd84486c9ae` and clean. Which exact app binary was running, whether a separate save file was used, and the host setup aren't confirmed. Two local windows sharing one process aren't separate physical devices. I'm not implying any changes to the source, report, presentation or original inventory, any new automated test run or any release approval.
