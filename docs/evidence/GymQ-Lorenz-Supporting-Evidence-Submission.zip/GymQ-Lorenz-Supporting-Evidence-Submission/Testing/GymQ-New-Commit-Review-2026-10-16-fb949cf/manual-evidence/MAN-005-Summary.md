# MAN-005: choosing equipment on the fault form, and validation

**Result: Passed for one workflow I ran in the real app with local windows.** The screenshots I took on 16 October 2026 cover both the valid report and the empty-description case. The supplied screenshots are retained with the observation notes. This isn't a usability study or a package acceptance result.

| Check | What I saw | Evidence |
|---|---|---|
| Different equipment in use and reported | Lorenz is still using Squat Rack #2 while the report is for Treadmill #3. | `MAN-005-Setup-Details.png`, `MAN-005-Staff-Report-Verified.png` |
| Equipment selector | The open selector shows Squat Rack #2 selected with Treadmill #3 in the list. The filled-in form later shows Treadmill #3 selected, with the matching image. | `MAN-005-Report-Selector-Open-SquatRack.png`, `MAN-005-Report-Treadmill-Before-Submit.png` |
| Message after a valid report | "Report submitted" and "Your report has been sent to gym staff for review." are shown. | `MAN-005-Report-Submitted.png` |
| What was saved for the report | Staff sees R-2, Treadmill #3, Lorenz Soriano and the exact description I typed. Pending count is 1. | `MAN-005-Staff-Report-Verified.png` |
| Empty description rejected | "Description cannot be empty" appears. The Treadmill #3 form stays open with no description and no success pop-up. | `MAN-005-Blank-Description-Validation.png` |
| No extra pending report | After the rejection, staff still sees 1 pending report: the same R-2 with the same machine, author and description. | `MAN-005-Staff-After-Blank-Rejection.png` |

**What I typed:** `MAN-005-1610: Test only — treadmill belt makes an unusual noise.` This is labelled test data. It isn't a claim about a real fault.

## How it was run, and the limits

- Device A first shows Christian's queue view, then the Gym Staff dashboard. Device B is Lorenz. These are two local windows sharing one process, not two physical devices.
- I used Lorenz as the active E2 member instead of Christian, the example account in the runbook. His active session and the equipment picked for the report are both shown in the evidence.
- The first report form, opened from the Treadmill #3 details page, is kept. A screenshot in between shows the Squat Rack details page, and I don't know what steps led to it. I'm not treating that image as a navigation bug. The later form screenshots show E2 and then the final E1 being selected. They don't record every click in the selector, and they don't prove the same form stayed open the whole time.
- The final staff comparison shows the visible pending list didn't change. I didn't separately inspect the raw save file, try submitting duplicates on purpose, or try a description with only spaces.
- Source checked: `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. The screenshots don't prove the exact app binary hash, the host OS version or whether a separate save file was used. The earlier 253/253 automated result is credited to that source build separately.
- This doesn't cover a staff decision, a maintenance status change, an authorisation attack, delivery to another device, performance or release approval.

Each image has a `.json` record with its original source path, preservation hash, what it shows and its limits. The original manual inventory, the project source, the student report and the slides are unchanged. See [Manual_Check_Progress.csv](Manual_Check_Progress.csv) for the guided test status after this.

**Where things were left for the next case:** R-2 is still pending on Treadmill #3, and there's no Confirm fault or Reject decision yet. The last screenshot from Device B shows the empty Treadmill report form with its validation message. If later steps need the active session, check it again, because the session timers keep running.
