# MAN-002: where the next-user notification evidence comes from

**Result for what I tested: Passed, using the same MAN-008 recording. It isn't a separate run.**

At 70.913 s, Christian is first in E2's queue, Lorenz is second and Jayden is using E2. Jayden ends his session normally, and at 71.722 s Christian gets the right **Squat Rack #2 / YOUR TURN** offer. Jayden goes back to Equipment and doesn't get a claim offer. The offer correctly makes Christian finish his E4 session first, and Go to Current Session is available. When the claim button is enabled later, it starts Christian's E2 session at 93.808 s. Lorenz stays next.

See the [MAN-008 summary](MAN-008-Summary.md) and the [timestamped structured observation](MAN-008-Observation.json) for the original recording hash, the frames, which account was in which window, and the limits. This is one guided observation using local windows in one shared process. It doesn't show notifications reaching a separate physical device, or a production notification system. Which exact app binary was running isn't confirmed. I didn't measure how fast the claim notification appeared.
