# MAN-007: confirming R-4, after the setup had changed

**MAN-007 wasn't complete after this attempt.** My 31.133-second recording confirms the fault and gives useful evidence that the current owner can still reach their session. But the queue-cancellation setup I'd planned no longer matched what was actually on screen.

| Check | Earlier setup screenshot | Start of the recording |
|---|---|---|
| E2 owner | Lorenz, 22:59 elapsed | Jayden, 05:27 elapsed |
| People waiting | Christian first, Jayden second | No waiting list is shown, so the real queue isn't confirmed |
| Unrelated E4 session | Recumbent Bike In Use; earlier owner Christian | Recumbent Bike Available |
| Fault report | R-4 pending for E2 | Same R-4 pending |

The change between these two states wasn't recorded, and I'm not claiming to know why the owner or the bike's state changed. The older screenshot can't prove what the queue and sessions looked like when the fault was confirmed later.

## What the recording does show

- At 2.000 s the pointer is on **Confirm fault** for R-4. By 2.917 s the pending count is **0**, R-4 is gone, E2 is **Out of Service**, and staff sees **Mark as available**.
- Jayden's E2 session keeps going. At 24.967 s he opens Equipment, and the E2 card says **Out of service. Please end your session** and still has **View Session**.
- By 29.997 s he has reopened his E2 session at **05:57**, with **End Session** available. This supports the current owner still being able to reach their session, related to GQ-05. I didn't press finish in this clip.

Jayden is the active owner in this clip, so it's expected that he doesn't get a queued-member cancellation message; that isn't a notification bug. This clip doesn't show a waiting member's message or an unrelated session staying the same.

## Evidence and limits

- `MAN-007-Confirm-R4.mov` (recording not included), SHA-256 `3944e7113ffc9d524346c03c46808b19bc2e62f22d398bb7904b690d37588e29`.
- Five PNGs taken straight from the video, with exact timestamps and hashes, are recorded in [MAN-007-Confirm-R4-Observation.json](MAN-007-Confirm-R4-Observation.json).
- The two local windows share one process. This doesn't give a result for separate physical devices, a precise input-speed result, the running binary hash, whether a separate save file was used, or release approval.
- The queue isn't visible, so I'm not assuming it was empty or that old entries stayed. I didn't inspect the raw save data.
- **Still to do at the time:** a setup with two people waiting, recorded at the time of the test; their removal from the queue; both people's messages; dismissing them and checking they don't come back; and an unrelated active session before and after the fault.

For a new cancellation trial, restore only E2, then set up and run the fresh test in one short continuous recording, so there are no long gaps between setting up and checking. Keep the actual current owner and the new report ID. The original inventory, project code, report and slides are unchanged.
