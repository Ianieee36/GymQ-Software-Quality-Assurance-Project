# MAN-009: the prototype's staff equipment dashboard

**Result for what I tested: Passed for the staff dashboard workflow in the real app.** The recording from 17 October 2026 adds the normal session-ending change, which was missing from the earlier fault-change evidence. It doesn't create a separate administrator role and doesn't waive the original FR009/AC09 wording about roles.

| Time in original video | What the member sees | Staff E2 status |
|---|---|---|
| 0.000 s | E2 Available, Start Session visible | Available |
| 3.000 s | Jayden's session running at 00:00 / 30:00 | In Use |
| 3.992 s | After ending, the member is back on Equipment | Available |
| 6.330 s | Jayden starts E2 again at 00:00 | In Use |
| 9.513 s | The new session reaches 00:02 / 29:58 | In Use |

All four staff equipment cards stay visible. Treadmill #3 and Elliptical #1 stay Out of Service, the Recumbent Bike stays In Use and pending reports stay at 0. The member and staff E2 states match the whole way through. The equipment was restored before this clip, so I'm not claiming the restore itself is shown here.

The earlier [MAN-006 evidence](MAN-006-Summary.md) shows a fault confirmed by staff changing E1 to Out of Service in both windows. The [MAN-007 retry](MAN-007-Retry-Observation.md) gives the E2 fault change, the all-equipment staff view and the unrelated E4 session staying the same. I'm reusing those observations on purpose; they aren't new runs from this short clip.

## Evidence and limits

- `MAN-009-Start-End-Start.mov` (recording not included): 9.727 seconds; SHA-256 `5919c0e65b70d8bc8c710ba619ede6948b9def66d1a0d030380972af1c6a4bab`.
- [Structured record with five original-frame hashes and timestamps](MAN-009-Observation.json).
- Device A is Jayden and Device B stays as Gym Staff. Two local windows in one process don't show syncing between separate physical devices.
- This is the prototype's **staff role**. The original wording about an administrator is still an unresolved difference, and I'm not making up an approval that the two roles are equal.
- This doesn't establish any measured input speed or load, which exact app binary was running, whether a separate save file was used, the host OS version, native package acceptance or human release approval.
- The source I checked is still `fb949cf7888976f1b51a39195b5a8dd84486c9ae`. No source changes or new automated runs were needed for this observation.

**Setup for the next case:** Jayden was last seen in a fresh E2 session. E4 is In Use, but check its timer and owner again before using Christian as the person with an active session in MAN-008. The original inventory, student report and slides are unchanged.
