# Evidence scope and handling

## Submission copies

Local computer paths were replaced with portable file or repository labels. Reviewer/tool metadata and preparation-only handoff notes were omitted from this submission copy. Technical outcomes, case IDs, dates, revisions and test counters were retained. Screenshots and saved business-data snapshots were not edited. The report is held separately in OneDrive.

The SHA256 manifest records the checksum of each submitted file. For a text record that was made portable, its original input checksum is also recorded. Existing hashes inside historical records describe the original evidence or source inputs, not the text-redacted submission copy. Use the root manifest to verify the submitted copy.

## Screenshots and recorded observations

No screen recordings or audio files are included. Some screenshots were extracted from recordings during the original checks; the notes retain the recording filenames, observation times and measured intervals as historical references. Those source recordings are not included. Screenshots alone do not prove continuous timing or audible announcements.

Older and partial observations remain dated. A later retry or summary can provide additional evidence without turning an earlier incomplete trial into a pass. The original manual inventory is a historical definition; use Manual_Check_Progress.csv and each case's latest summary for current status.

The MAN-015 save-file snapshots are fixed copies from before quit, after quit and after relaunch. Matching bytes across stages are retained deliberately to support the restart comparison. Its build manifest and logs describe the source build, not an installer. The unused preparation launcher and changing working data are not included.

## Limits carried into the report

- MAN-001: local samples do not establish normal-load response time. The third observation's conservative upper bound does not prove the one-second target.
- MAN-003: the current prototype uses a two-minute nudge response window; the earlier one-minute acceptance wording remains a baseline conflict.
- MAN-008: the observed claim-recovery route does not demonstrate the member's own ended-session history after handover.
- MAN-014: the accessible-name findings remain open; scaling was not run.
- MAN-015: one pending report survived one normal restart of the isolated macOS source build. Installer, clean install, self-contained packaging, Windows and other saved-state scenarios remain unverified.
- The two local windows share one coordinator. They are not two independent physical clients.
- The historical coverage file combines Core and Desktop and is not a new measurement of fb949cf or a Core-only coverage result.

No human release sign-off is supplied by this folder. No tests were rerun while creating it.
